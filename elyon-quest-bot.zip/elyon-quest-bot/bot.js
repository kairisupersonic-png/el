/**
 * Elyon Quest Bot — Testnet Season 1
 * Hanya 2 step otomatis (sesuai request):
 *   1. Claim faucet ELN  -> call claim() di campaign contract
 *   2. Send a transaction -> kirim 1 ELN ke RECIPIENT
 *
 * Step lain (delegate, mint badge, tweet, comment, link X/Telegram)
 * dibiarkan manual di https://airdrop.elyon.network/
 *
 * PENTING: wallet harus punya sedikit gas ELN untuk bensin tx.
 * Jika saldo gas < 0.01 ELN, login manual di website dulu
 * (site otomatis top-up gas via /v1/gas/topup).
 */
const { ethers } = require('ethers');
const CONFIG = require('./config');

const CAMPAIGN_ABI = ['function claim()'];

const log = (...a) => console.log(new Date().toISOString(), ...a);

async function waitMined(provider, txHash, maxSec = 180) {
  const t0 = Date.now();
  while (Date.now() - t0 < maxSec * 1000) {
    try {
      const tx = await provider.getTransactionReceipt(txHash);
      if (tx && tx.blockNumber) return tx;
    } catch {}
    await new Promise((r) => setTimeout(r, 3000));
  }
  return null;
}

function friendlyError(e) {
  const m = (e && (e.reason || e.shortMessage || e.message)) || String(e);
  if (/faucet empty|being refilled/i.test(m)) return 'Faucet sedang diisi ulang — coba lagi nanti.';
  if (/excluded from the elyon campaign/i.test(m)) return 'Wallet ini di-exclude dari campaign.';
  if (/already|once per|cooldown|too soon/i.test(m)) return 'Sudah claim hari ini (sekali per hari).';
  if (/insufficient funds/i.test(m)) return 'Saldo gas kurang. Login manual di website dulu agar dapat top-up gas.';
  return m;
}

async function main() {
  if (!CONFIG.PRIVATE_KEY) throw new Error('PRIVATE_KEY kosong — isi di file .env');
  const wallet = new ethers.Wallet(CONFIG.PRIVATE_KEY);
  const provider = new ethers.JsonRpcProvider(CONFIG.RPC_URL, CONFIG.CHAIN_ID, { staticNetwork: true });
  const signer = wallet.connect(provider);
  const me = await signer.getAddress();

  const netId = (await provider.send('eth_chainId', []));
  if (parseInt(netId, 16) !== CONFIG.CHAIN_ID) throw new Error('Chain ID salah: ' + netId);

  const bal = await provider.getBalance(me);
  log(`Wallet : ${me}`);
  log(`Saldo  : ${ethers.formatEther(bal)} ELN`);

  if (bal < ethers.parseEther('0.005')) {
    log('⚠️  Saldo gas sangat rendah. Login manual ke airdrop.elyon.network agar dapat top-up gas, lalu jalankan lagi.');
  }

  // ── Step 1: Claim faucet ELN ──────────────────────────────
  log('STEP 1: Claim faucet ELN ...');
  try {
    const c = new ethers.Contract(CONFIG.CAMPAIGN_CONTRACT, CAMPAIGN_ABI, signer);
    // Simulasi dulu: kalau revert, kita tahu alasannya TANPA membakar gas.
    // (RPC Elyon kadang tidak mengembalikan pesan revert saat estimateGas,
    //  yang menyebabkan error samar "missing revert data".)
    try {
      await c.claim.staticCall();
    } catch (sim) {
      const r = (sim.revert && sim.revert.args && sim.revert.args.join(', ')) || sim.reason || sim.shortMessage || sim.message;
      log('  ✗ Claim tidak akan berhasil (simulasi revert):', r);
      log('    → Kemungkinan: sudah claim hari ini, wallet di-exclude, atau faucet kosong. Coba besok.');
    }
    const tx = await c.claim();
    log('  claim tx:', tx.hash);
    const rc = await waitMined(provider, tx.hash);
    if (rc) {
      const ok = rc.status === 1;
      log(ok ? `  ✓ Claim OK — block ${rc.blockNumber}` : `  ✗ Claim tx REVERTED di block ${rc.blockNumber} (gas terpakai, coba besok / cek alasan di atas)`);
    } else {
      log('  ⏳ tx terkirim tapi belum masuk block (cek explorer)');
    }
    log(`  ${CONFIG.EXPLORER}/tx/${tx.hash}`);
  } catch (e) {
    log('  ✗ Claim gagal:', friendlyError(e));
  }

  // ── Step 2: Send a transaction (1 ELN) ────────────────────
  if (CONFIG.RECIPIENT && ethers.isAddress(CONFIG.RECIPIENT)) {
    if (CONFIG.RECIPIENT.toLowerCase() === me.toLowerCase()) {
      log('STEP 2: DILEWATI — RECIPIENT = wallet sendiri (tidak dihitung poin).');
    } else {
      log('STEP 2: Send 1 ELN ...');
      try {
        const tx = await signer.sendTransaction({
          to: CONFIG.RECIPIENT,
          value: ethers.parseEther(CONFIG.SEND_AMOUNT),
        });
        log('  send tx:', tx.hash);
        const rc = await waitMined(provider, tx.hash);
        if (rc) {
          const ok = rc.status === 1;
          log(ok ? `  ✓ Send OK — block ${rc.blockNumber}` : `  ✗ Send tx REVERTED di block ${rc.blockNumber}`);
        } else {
          log('  ⏳ tx terkirim tapi belum masuk block (cek explorer)');
        }
        log(`  ${CONFIG.EXPLORER}/tx/${tx.hash}`);
      } catch (e) {
        log('  ✗ Send gagal:', friendlyError(e));
      }
    }
  } else {
    log('STEP 2: DILEWATI — isi RECIPIENT di .env (address lain, bukan wallet sendiri).');
  }

  log('Selesai. Step lainnya (delegate, mint badge, tweet, dsb) dikerjakan manual di website.');
}

main().catch((e) => { console.error('FATAL:', friendlyError(e)); process.exit(1); });
