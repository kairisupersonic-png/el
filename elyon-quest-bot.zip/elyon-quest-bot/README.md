# Elyon Quest Bot (Testnet Season 1)

Bot harian untuk 2 step quest di https://airdrop.elyon.network/:

| Step | Aksi | Poin |
|---|---|---|
| 02 | **Claim faucet ELN** | +20/hari |
| 03 | **Send a transaction** (1 ELN ke address lain) | +15/hari |

Step lainnya (delegate, mint badge, tweet, comment, link X/Telegram, Discord) **dibiarkan manual** di website.

## Setup

```bash
npm install          # install ethers v6
cp .env.example .env # lalu edit .env
```

Isi `.env`:
- `PRIVATE_KEY` — private key wallet testnet kamu (wallet khusus testnet saja!)
- `RECIPIENT` — address penerima untuk send 1 ELN (harus address lain, bukan wallet sendiri)

## Jalankan

```bash
npm start            # atau: node bot.js
```

Output: hash tx + link explorer `https://explorertestnet.elyon.network/tx/...`

## Catatan penting

1. **Gas**: wallet butuh sedikit ELN untuk gas. Kalau saldo < 0.01 ELN, login manual ke
   airdrop.elyon.network — situs otomatis top-up gas (`/v1/gas/topup`) setelah connect wallet.
2. **Captcha / Proof-of-Human**: verifikasi email + captcha hanya ada di **login website**,
   bukan di transaksi on-chain. Jadi: daftar/login dan link wallet tetap manual sekali saja.
   Setelah akun aktif, backend situs otomatis mendeteksi transaksi claim & send di chain.
3. **Jadwal harian**: claim & send reset tiap hari kampanye. Jalankan bot sekali per hari,
   misal via cron: `0 9 * * * cd /path/elyon-bot && node bot.js >> bot.log 2>&1`
4. **Risiko ToS**: situs menyatakan larangan bot/script untuk aktivitas poin. Dua step ini
   murni transaksi on-chain yang sama seperti yang kamu lakukan manual, tapi gunakan dengan
   bijak — wallet yang dianggap melanggar bisa di-exclude dari poin.
5. JANGAN pernah memasukkan private key wallet mainnet ke `.env`.

## Struktur

```
bot.js          # logika claim + send
config.js       # baca .env + konstanta network
.env.example    # template env
```
