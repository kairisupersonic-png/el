// ====== CONFIG — edit di sini atau lewat file .env ======
require('dotenv').config();

const CONFIG = {
  // Private key wallet testnet kamu (JANGAN pakai wallet mainnet!)
  PRIVATE_KEY: process.env.PRIVATE_KEY || '',

  // Address penerima untuk step "Send a transaction"
  // HARUS address lain, bukan wallet sendiri (tidak dihitung poin)
  RECIPIENT: process.env.RECIPIENT || '',

  // Network Elyon testnet
  RPC_URL: process.env.RPC_URL || 'https://testnet.elyon.network/rpc',
  CHAIN_ID: 55452774,

  // Contract campaign (faucet claim)
  CAMPAIGN_CONTRACT: process.env.CAMPAIGN_CONTRACT || '0xa73d15a71fe3e267169e3c773074c5addffd14a1',

  // Jumlah ELN yang dikirim untuk step send_tx
  SEND_AMOUNT: process.env.SEND_AMOUNT || '1.0',

  EXPLORER: 'https://explorertestnet.elyon.network',
};

module.exports = CONFIG;
